﻿[System.Serializable]

public class SoaldanJawaban
{
    public string question;
    public string[] answers;
    public int correctAnswer;
}
